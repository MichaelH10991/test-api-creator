# test-api-creator

Just to make sure everything works ok.

Simply run:

`npm i`

`npm start`
