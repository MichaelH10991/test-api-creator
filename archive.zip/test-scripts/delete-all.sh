#!/bin/bash

curl -X DELETE http://localhost:8080/delete