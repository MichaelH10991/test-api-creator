#!/bin/bash

curl -X POST http://`hostname`:8080/create \
  -H "Content-Type: application/json" \
  -d '{
    "language": "Croatian",
    "group": "greetings",
    "local": "Hello",
    "foreign": "Zdravo"
  }'

curl -X POST http://`hostname`:8080/create \
  -H "Content-Type: application/json" \
  -d '{
    "language": "Croatian",
    "group": "greetings",
    "local": "Hi",
    "foreign": "Bok"
  }'

curl -X POST http://`hostname`:8080/create \
  -H "Content-Type: application/json" \
  -d '{
    "language": "Croatian",
    "group": "resturant",
    "local": "Table",
    "foreign": "Stol"
  }'

  curl -X POST http://`hostname`:8080/create \
    -H "Content-Type: application/json" \
    -d '{
      "language": "Spanish",
      "group": "resturant",
      "local": "Table",
      "foreign": "Stol"
    }'