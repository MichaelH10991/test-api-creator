#!/bin/bash

zip -r archive.zip .