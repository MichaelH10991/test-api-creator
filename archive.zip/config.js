module.exports = {
  serviceName: "api-creator-test",
  corsOptions: {},
  bodyParserOptions: {
    bodyParserEnabled: true,
  },
  bodyParserEnabled: true,
  db: {
    uri: "mongodb://admin:admin@52.48.67.168:27017/language-quiz?authSource=admin",
  },
};
